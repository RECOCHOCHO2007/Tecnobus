<?php
// get_reserved_seats.php
require_once 'db_connection.php';
header("Content-Type: application/json; charset=UTF-8");

$response = ["success" => false, "message" => "Ocurrió un error inesperado."];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = json_decode(file_get_contents("php://input"));
    $schedule_id = $data->schedule_id ?? null;

    if ($schedule_id) {
        try {
            $sql = "SELECT seat_number FROM reservations WHERE schedule_id = :schedule_id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['schedule_id' => $schedule_id]);
            $reserved_seats = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Reorganizamos el array para que sea una lista simple de números
            $seat_numbers = array_map(function($item) {
                return $item['seat_number'];
            }, $reserved_seats);

            $response = ["success" => true, "seats" => $seat_numbers];

        } catch (PDOException $e) {
            $response["message"] = "Error en la base de datos: " . $e->getMessage();
        }
    } else {
        $response["message"] = "ID de viaje no proporcionado.";
    }
} else {
    $response["message"] = "Método de solicitud no válido.";
}

echo json_encode($response);
?>