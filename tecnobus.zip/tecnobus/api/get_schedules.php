<?php
// get_schedules.php
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    $origin = $data->origin ?? '';
    $destination = $data->destination ?? '';

    $sql = "SELECT * FROM schedules WHERE origin_id IN (SELECT id FROM destinations WHERE name = ?) AND destination_id IN (SELECT id FROM destinations WHERE name = ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $origin, $destination);
    $stmt->execute();
    $result = $stmt->get_result();

    $schedules = [];
    while($row = $result->fetch_assoc()) {
        $schedules[] = $row;
    }

    echo json_encode(["success" => true, "schedules" => $schedules]);

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Método de solicitud no permitido."]);
}
?>