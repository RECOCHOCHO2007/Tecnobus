<?php
// register.php
session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    $name = $data->name ?? '';
    $email = $data->email ?? '';
    $password = $data->password ?? '';

    if (empty($name) || empty($email) || empty($password)) {
        echo json_encode(["success" => false, "message" => "Por favor, completa todos los campos."]);
        $conn->close();
        exit();
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["success" => false, "message" => "El formato del email es inválido."]);
        $conn->close();
        exit();
    }
    
    if (strlen($password) < 8) {
        echo json_encode(["success" => false, "message" => "La contraseña debe tener al menos 8 caracteres."]);
        $conn->close();
        exit();
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $hashed_password);

    if ($stmt->execute()) {
        $_SESSION['user_id'] = $stmt->insert_id;
        $_SESSION['user_email'] = $email;
        echo json_encode(["success" => true, "message" => "Registro exitoso. Se ha iniciado sesión."]);
    } else {
        if ($conn->errno == 1062) {
            echo json_encode(["success" => false, "message" => "El email ya está registrado."]);
        } else {
            echo json_encode(["success" => false, "message" => "Error al registrar usuario: " . $stmt->error]);
        }
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Método de solicitud no permitido."]);
}
?>