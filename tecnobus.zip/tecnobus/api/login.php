<?php
// login.php
session_start();
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    $email = $data->email ?? '';
    $password = $data->password ?? '';

    if (empty($email) || empty($password)) {
        echo json_encode(["success" => false, "message" => "Por favor, ingresa tu email y contraseña."]);
        $conn->close();
        exit();
    }

    $stmt = $conn->prepare("SELECT id, name, email, password, balance, phone FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
            
            unset($user['password']);
            echo json_encode(["success" => true, "message" => "Inicio de sesión exitoso.", "user" => $user]);
        } else {
            echo json_encode(["success" => false, "message" => "Credenciales incorrectas."]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "Credenciales incorrectas."]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["success" => false, "message" => "Método de solicitud no permitido."]);
}
?>