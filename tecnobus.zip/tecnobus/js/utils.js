// js/utils.js

/**
 * Muestra un mensaje de retroalimentación en un elemento del DOM.
 * @param {HTMLElement} element - El elemento donde se mostrará el mensaje.
 * @param {string} message - El mensaje a mostrar.
 * @param {string} type - El tipo de mensaje ('success', 'error', 'info').
 */
export const showFeedback = (element, message, type) => {
    if (element) {
        element.textContent = message;
        element.className = `feedback ${type}`;
        element.style.display = 'block';
    }
};

/**
 * Oculta un mensaje de retroalimentación de un elemento del DOM.
 * @param {HTMLElement} element - El elemento que se va a ocultar.
 */
export const hideFeedback = (element) => {
    if (element) {
        element.textContent = '';
        element.style.display = 'none';
    }
};

/**
 * Guarda el objeto de usuario en localStorage.
 * @param {object} user - El objeto de usuario a guardar.
 */
export const saveUserData = (user) => {
    try {
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('isAuthenticated', 'true');
    } catch (e) {
        console.error("Error al guardar datos en localStorage", e);
    }
};

/**
 * Obtiene el objeto de usuario desde localStorage.
 * @returns {object|null} - El objeto de usuario si existe, de lo contrario, null.
 */
export const getUserData = () => {
    try {
        const user = localStorage.getItem('user');
        return user ? JSON.parse(user) : null;
    } catch (e) {
        console.error("Error al obtener datos de localStorage", e);
        return null;
    }
};

/**
 * Elimina los datos del usuario de localStorage.
 */
export const removeUserData = () => {
    try {
        localStorage.removeItem('user');
        localStorage.removeItem('isAuthenticated');
    } catch (e) {
        console.error("Error al eliminar datos de localStorage", e);
    }
};