// js/api.js (Versión con ruta asumida 'api/' para el 404 de PHP)

const API_BASE_URL = 'http://localhost/tecnobus/'; 

const postData = async (endpoint, data) => {
    // ... (código postData function)
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });

        if (!response.ok) {
            if (response.status === 404) {
                 return { success: false, message: "Error de conexión: Archivo PHP no encontrado (404)." };
            }
            return { success: false, message: `Error de servidor. Código: ${response.status}` };
        }

        return await response.json();
    } catch (error) {
        console.error('Error en la conexión a la API:', error);
        return { success: false, message: 'Error de conexión con el servidor.' };
    }
};

export const login = (email, password) => {
    // Usa 'api/login.php' si resolviste el 404 creando la carpeta 'api'
    return postData('api/login.php', { email, password }); 
};

export const register = (name, email, password) => {
    // Usa 'api/register.php'
    return postData('api/register.php', { name, email, password });
};

// 👇 ESTA FUNCIÓN DEBE ESTAR EXPORTADA
export const logout = async () => {
    // Aquí puedes incluir una llamada a la API para invalidar el token en el servidor si lo deseas.
    // Por ahora, solo simula un cierre de sesión exitoso.
    console.log("Logout llamado en API.js");
    return { success: true };
};