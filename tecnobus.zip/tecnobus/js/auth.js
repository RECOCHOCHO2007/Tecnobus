// js/auth.js 

// --- 1. Importaciones ---
import { showFeedback, hideFeedback } from './utils.js';
import { login, register } from './api.js';
import { handleAuthState } from './app.js'; 


// --- 2. Selectores del DOM ---
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const showRegisterBtn = document.getElementById('show-register-btn');
const showLoginBtn = document.getElementById('show-login-btn');
const loginFeedback = document.getElementById('login-feedback');
const registerFeedback = document.getElementById('register-feedback');


// --- 3. Funciones de Control de Vistas ---

export const showAuthView = () => {
    handleAuthState(false); 
};

const showRegisterForm = () => {
    // Oculta login y muestra registro
    if (loginForm) loginForm.classList.add('hidden');
    if (registerForm) registerForm.classList.remove('hidden');
    
    // Limpia mensajes
    if (loginFeedback) hideFeedback(loginFeedback);
    if (registerFeedback) hideFeedback(registerFeedback);
};

const showLoginForm = () => {
    // Muestra login y oculta registro
    if (loginForm) loginForm.classList.remove('hidden');
    if (registerForm) registerForm.classList.add('hidden');
    
    // Limpia mensajes
    if (loginFeedback) hideFeedback(loginFeedback);
    if (registerFeedback) hideFeedback(registerFeedback);
};


// --- 4. Event Listeners de Cambio de Vista (CORRECCIÓN DEL TYPEERROR) ---
// La comprobación 'if (showRegisterBtn)' previene el TypeError.
// La corrección clave es asegurar que el elemento exista al cargar (por eso el cambio a .hidden en HTML/CSS)

if (showRegisterBtn) {
    showRegisterBtn.addEventListener('click', (e) => {
        e.preventDefault();
        showRegisterForm();
    });
}

if (showLoginBtn) {
    showLoginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        showLoginForm();
    });
}


// --- 5. Lógica de LOGIN ---
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => { 
        e.preventDefault();
        hideFeedback(loginFeedback);
        
        const email = loginForm.querySelector('#login-email').value;
        const password = loginForm.querySelector('#login-password').value;
        
        const result = await login(email, password);
        
        if (result.success) {
            localStorage.setItem('isAuthenticated', 'true');
            localStorage.setItem('user', JSON.stringify(result.user));
            await handleAuthState(true, result.user); 
        } else {
            showFeedback(loginFeedback, result.message || "Credenciales incorrectas.", 'error');
        }
    });
}


// --- 6. Lógica de REGISTRO ---
if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        hideFeedback(registerFeedback);
        
        const name = registerForm.querySelector('#register-name').value;
        const email = registerForm.querySelector('#register-email').value;
        const password = registerForm.querySelector('#register-password').value;
        const confirmPassword = registerForm.querySelector('#register-confirm-password').value;

        if (password !== confirmPassword) {
            showFeedback(registerFeedback, 'Las contraseñas no coinciden.', 'error');
            return;
        }

        const result = await register(name, email, password); 
        
        if (result.success) {
            showFeedback(registerFeedback, result.message, 'success');
            setTimeout(() => {
                showLoginForm(); 
                hideFeedback(registerFeedback);
            }, 2000);
        } else {
            showFeedback(registerFeedback, result.message || "Error al intentar registrar el usuario.", 'error');
        }
    });
}