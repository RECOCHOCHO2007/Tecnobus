// js/app.js

import { logout } from './api.js'; 

const authView = document.getElementById('auth-view');
const appContainer = document.getElementById('app-container');
const logoutBtn = document.getElementById('logout-btn');

// Elementos de la UI que muestran datos del usuario (para actualizar)
const profileCardName = document.getElementById('profile-card-name');
const profileCardEmail = document.getElementById('profile-card-email');
const infoNombre = document.getElementById('info-nombre');
const infoEmail = document.getElementById('info-email');


const updateProfileUI = (user) => {
    if (user && profileCardName) profileCardName.textContent = user.name || 'Usuario';
    if (user && profileCardEmail) profileCardEmail.textContent = user.email || 'email@ejemplo.com';
    
    // Asigna también a los campos del formulario de perfil
    if (user && infoNombre) infoNombre.value = user.name || '';
    if (user && infoEmail) infoEmail.value = user.email || '';
};

/**
 * Maneja el estado de autenticación (Muestra/Oculta Auth/App).
 * @param {boolean} isAuthenticated - Si el usuario está logueado.
 * @param {object} user - Datos del usuario logueado.
 */
export const handleAuthState = (isAuthenticated, user = null) => {
    if (isAuthenticated) {
        if (authView) authView.classList.add('hidden'); // Oculta Auth
        if (appContainer) appContainer.classList.remove('hidden'); // Muestra App
        
        // Carga los datos en la UI
        updateProfileUI(user);
        
    } else {
        if (authView) authView.classList.remove('hidden'); // Muestra Auth
        if (appContainer) appContainer.classList.add('hidden'); // Oculta App
        console.log("Usuario ha cerrado sesión.");
    }
};

// Event Listener para el botón de cerrar sesión
if (logoutBtn) {
    logoutBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        
        await logout(); // Llama a la función de la API
        
        // Limpia el almacenamiento local
        localStorage.removeItem('isAuthenticated');
        localStorage.removeItem('user');
        
        handleAuthState(false);
    });
}

// Inicializa la aplicación comprobando el estado de autenticación al cargar la página
document.addEventListener('DOMContentLoaded', () => {
    const isAuthenticated = localStorage.getItem('isAuthenticated') === 'true';
    const user = JSON.parse(localStorage.getItem('user'));
    
    handleAuthState(isAuthenticated, user);
});